class Blog < ApplicationRecord
end
